import React, { Component, useState, useEffect } from "react";
import Web3 from "web3";
import {
    contractAddress,
    contractabi,
} from "../utils/constant";
import './myaccount.css';
import { ToastContainer, toast } from 'react-toastify';

function Myaccount() {
    return (
        <div className="container-fluid">
            <div className="Navbar">
                <div className="rightSide">
                    <h1>MY ACCOUNT</h1>
                </div>
            </div >
            <div className="container">
                <div className="col-sm-8">
                    <div className="row">
                        <div className="col-sm-12 accounttime">
                            <p>Account Balance -  </p>
                            {/* <p> - </p> */}
                            <span> as of </span>
                            <span> 25 Jun 2021, 7:15pm</span>
                        </div>
                    </div>
                    <div className="row ">
                        <div className="col accountbalance">
                            <h1>265</h1>
                            <span>BSB</span>
                        </div>
                        <div className="col accountbalance">
                            <h1>163</h1>
                            <span>BNB</span>
                        </div>
                    </div>
                    <div className="row">
                        <div className="accounthistory"> <h4> Transactions History</h4> </div>
                        <div className="accounthistory"> <p> Showing Last 5 Transactions </p> </div>
                    </div>
                    <div className="row accounttransactions">
                        <div className="col-md accounthead">
                            <p>No.</p>
                        </div>
                        <div className="col-md">
                            <p>Date</p>
                        </div>
                        <div className="col-md">
                            <p>Transaction</p>
                        </div>
                        <div className="col-md">
                            <p>Amount</p>
                        </div>
                        <div className="col-md">
                            <p>Type</p>
                        </div>
                        <div className="col-md">
                            <p>Balance</p>
                        </div>
                        <div className="col-md">
                            <p>Remarks</p>
                        </div>
                    </div>


                    <div className="row accounttransactions">
                        <div className="col accounthead">
                            <span>No.</span>
                        </div>
                        <div className="col">
                            <span>Date</span>
                        </div>
                        <div className="col">
                            <span>Transaction</span>
                        </div>
                        <div className="col">
                            <span>Amount</span>
                        </div>
                        <div className="col">
                            <span>Type</span>
                        </div>
                        <div className="col">
                            <span>Balance</span>
                        </div>
                        <div className="col">
                            <span>Remarks</span>
                        </div>
                    </div>
                    <div className="row" style={{ margin: "3rem" }}></div>
                </div>
            </div>
        </div >
    );
}

export default Myaccount;
